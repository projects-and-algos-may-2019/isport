$(document).ready(function() {
     $('#rBtn').click(function(){
          $('.rForm').toggle();
     })
     $('#lBtn').click(function(){
          $('.lForm').toggle();
     })

})
